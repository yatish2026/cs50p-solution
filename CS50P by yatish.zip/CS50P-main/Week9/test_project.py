from project import tomato, progressbar, notify_me


def test_tomato():
    assert "print" == "print"


def test_progressbar():
    assert "no" == "no"


def test_notify_me():
    assert "test" == "test"
