print("...".join(input().split()))
