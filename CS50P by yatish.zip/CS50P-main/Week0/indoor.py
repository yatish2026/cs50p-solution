print(input().lower())
