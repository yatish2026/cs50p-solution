def compute(m, c=300000000):
    return m * c * c


print("E:", compute(int(input("m: "))))
