# Harvard CS50 Python 2022

- [Course Link](https://cs50.harvard.edu/python)
